// onsubmit on click to active function
function validateform(event) {
  event.preventDefault();

  //firstname get
  var firstname = document.forminput.inputfname.value.trim();
  let name = /^[A-Za-z]+$/;
  let fnamevalid = name.test(firstname);

  //lastname get
  var lastname = document.forminput.inputlname.value.trim();
  let lnamevalid = name.test(lastname);

  //phonenumber get
  var num = document.forminput.numberinput.value.trim();
  let regex = /^[0-9]{10}$/;
  let phoneregx = regex.test(num);

  //birthday get
  var dob = document.forminput.birthday.value;

  //email get
  var mail = document.forminput.emailinput.value.trim();
  let emailregex = /^[a-z0-9?.!#$%^&'*+_`~-]+@[a-z]+\.[a-z]+$/;
  let emailvalid = emailregex.test(mail);

  //password get
  var pass = document.forminput.password.value;
  let passwordregex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()-_+=])[A-Za-z\d!@#$%^&*()-_+=]{4,}$/;
  let passwordvalid = passwordregex.test(pass);

  // repassword get
  let repass = document.forminput.repassword.value;

  function validation(firstname, lastname, dob, num, mail, pass) {
    // firstname validate
    if (firstname == "" || firstname == null) {
      document.getElementById("fname error").innerHTML =
        "Please enter your first name.xxxxxxxx";
    } else {
      document.getElementById("fname error").innerHTML = "";
    }
    // lastname validate
    if (lastname == "" || lastname == null) {
      document.getElementById("lname error").innerHTML =
        "Please enter your last name. xxxxxx";
    } else {
      document.getElementById("lname error").innerHTML = "";
    }
    // dob validate
    if (dob == "" || dob == null) {
      document.getElementById("dob error").innerHTML =
        "Please enter your Birthday. xxxxxxxx ";
    } else {
      document.getElementById("dob error").innerHTML = "";
    }
    // num validate
    if (num == "" || num == null) {
      document.getElementById("number error").innerHTML =
        "Please enter your Phone Number. xxxxx";
    } else {
      document.getElementById("number error").innerHTML = "";
    }
    // mail validate
    if (mail == "" || mail == null) {
      document.getElementById("email error").innerHTML =
        "Please enter your email. xxxx";
    } else {
      document.getElementById("email error").innerHTML = "";
    }
    // pass validate
    if (pass == "" || pass == null) {
      document.getElementById("pwd error").innerHTML =
        "Please enter your password. xxxx";
    } else {
      document.getElementById("pwd error").innerHTML = "";
    }

  }

  validation(firstname, lastname, dob, num, mail, pass, repass);

  //   first name js
  if (firstname == "" || firstname == null) {
    document.getElementById("fname error").innerHTML =
      "Please enter your first name. yy";
    return false;
  } else if (fnamevalid == false) {
    document.getElementById("fname error").innerHTML =
      "Enter Only Character Not Number.yyyyy";
    return false;
  } else {
    document.getElementById("fname error").innerHTML = "";
  }

  //  last name js
  if (lastname == "" || lastname == null) {
    document.getElementById("lname error").innerHTML =
      "Please enter your last name.yyyyyyyyyy ";
    return false;
  } else if (lnamevalid == false) {
    document.getElementById("lname error").innerHTML =
      "Enter Only Character Not Number.yyyyyyy";
    return false;
  } else {
    document.getElementById("lname error").innerHTML = "";
  }

  //   phone number input js
  if (isNaN(Number(num))) {
    document.getElementById("number error").innerHTML =
      "Please Enter Number Not Character.yyyyyy";
    return false;
  } else if (phoneregx == false) {
    document.getElementById("number error").innerHTML =
      "Valid Number required.yyyyy";
    return false;
  } else {
    document.getElementById("number error").innerHTML = "";
  }

  //  email input js
  if (emailvalid == false) {
    document.getElementById("email error").innerHTML = "Valid Email required.yyyy";
    return false;
  } else {
    document.getElementById("email error").innerHTML = "";
  }

  // password input and match
  if (passwordvalid == false) {
    document.getElementById("pwd error").innerHTML =
      "one lowercase letter,one uppercase letter,one digit ,one special character ,Minimum length 8 characters.yyyy";
    return false;
  } else {
    document.getElementById("pwd error").innerHTML = "";
  }

  //confirm password input
  if (repass == "" || repass == null) {
    document.getElementById("repwd error").innerHTML = "Enter Confirm password.yyy";
    return false;
  } else if (pass != repass) {
    document.getElementById("repwd error").innerHTML = "Password don't match.yyyy";
    return false;
  } else {
    document.getElementById("repwd error").innerHTML = "";
  }

  // store data ni localstorage
  function submit() {
    var firstname = document.getElementById("inputfname").value;
    var lastname = document.getElementById("inputlname").value;
    var dob = document.getElementById("birthday").value;
    var num = document.getElementById("numberinput").value;
    var mail = document.getElementById("emailinput").value;
    var pass = document.getElementById("password").value;
    var Gender = document.getElementById("gender");

    Gender.checked ? (gender = "Male") : (gender = "Female");

    var formSubmissions =
      JSON.parse(localStorage.getItem("formSubmissions")) || [];

    var formData = {
      Firstname: firstname,
      Lastname: lastname,
      Gender: gender,
      Birthday: dob,
      phonenumber: num,
      email: mail,
      password: pass,
    };

    formSubmissions.push(formData);

    localStorage.setItem("formSubmissions", JSON.stringify(formSubmissions));
    document.getElementById("myForm").reset();
    displayFormSubmissions();
  }
  // submit called
  submit();
}
document.getElementById("myForm").reset();

// data show in table
function displayFormSubmissions() {
  var tabledata = document.querySelector(".table_data");
  var formSubmissions =
    JSON.parse(localStorage.getItem("formSubmissions")) || [];
  var elements = "";

  formSubmissions.map((submission, index) => {
    elements += `<tr>
    <td>${submission.Firstname}</td>
    <td>${submission.Lastname}</td>
    <td>${submission.Gender}</td>
    <td>${submission.Birthday}</td>
    <td>${submission.phonenumber}</td>
    <td>${submission.email}</td>
    <td>${submission.password}</td>
    <td>
    <button class="edit-btn" id="editbtn" data-index="${index}">Edit</button>
    &nbsp;
    <input type="button" class="delete-btn" data-index="${index}" value="Delete" /></td>
    </tr>`;
  });
  tabledata.innerHTML = elements;

  function deleteFormSubmission(index) {
    formSubmissions.splice(index, 1);
    localStorage.setItem("formSubmissions", JSON.stringify(formSubmissions));
    displayFormSubmissions();
  }
  // submit after data clear
  function populateFormForEdit(submission, index) {
    document.getElementById("inputfname").value = submission.Firstname || "";
    document.getElementById("inputlname").value = submission.Lastname || "";
    document.getElementById("gender").value = submission.Gender || "";
    document.getElementById("birthday").value = submission.Birthday || "";
    document.getElementById("numberinput").value = submission.phonenumber || "";
    document.getElementById("emailinput").value = submission.email || "";
    document.getElementById("password").value = submission.password || "";

    document.getElementById("update").setAttribute("data-index", index);
  }

  // update button click event
  document.getElementById("update").addEventListener("click", function () {
    var index = parseInt(
      document.getElementById("update").getAttribute("data-index")
    );
    var formSubmissions =
      JSON.parse(localStorage.getItem("formSubmissions")) || [];

    //firstname input for update
    var firstname = document.forminput.inputfname.value.trim();
    let name = /^[A-Za-z]+$/;
    let fnamevalid = name.test(firstname);
    var lastname = document.forminput.inputlname.value.trim();
    let lnamevalid = name.test(lastname);

    // phone number input for update
    var num = document.forminput.numberinput.value.trim();
    let regex = /^[0-9]{10}$/;
    let phoneregx = regex.test(num);

    //birthday input for update
    var dob = document.forminput.birthday.value;

    //email input for update
    var mail = document.forminput.emailinput.value.trim();
    let emailregex = /^[a-z0-9?.!#$%^&'*+_`~-]+@[a-z]+\.[a-z]+$/;
    let emailvalid = emailregex.test(mail);

    // password input for update
    var pass = document.forminput.password.value;
    let passwordregex =
      /^(?=.*[A-Z])(?=.*[a-z])(?=.*[@#$%^&*!])(?=.*[0-9]).{6,15}$/;
    let passwordvalid = passwordregex.test(pass);

    // repassword input for update
    let repass = document.forminput.repassword.value;

    // function validation update before
    function validation(firstname, lastname, dob, num, mail, pass) {

      // firstname
      if (firstname == "" || firstname == null) {
        document.getElementById("fname error").innerHTML =
          "Please enter your first name.aaaa ";
      } else {
        document.getElementById("fname error").innerHTML = "";
      }

      // lastname
      if (lastname == "" || lastname == null) {
        document.getElementById("lname error").innerHTML =
          "Please enter your last name.aaaa ";
      } else {
        document.getElementById("lname error").innerHTML = "";
      }

      // dob
      if (dob == "" || dob == null) {
        document.getElementById("dob error").innerHTML =
          "Please enter your Birthday.aaaa  ";
      } else {
        document.getElementById("dob error").innerHTML = "";
      }

      // number
      if (num == "" || num == null) {
        document.getElementById("number error").innerHTML =
          "Please enter your Phone Number.aaaaaaa ";
      } else {
        document.getElementById("number error").innerHTML = "";
      }

      // email
      if (mail == "" || mail == null) {
        document.getElementById("email error").innerHTML =
          "Please enter your email. aaaaaaa";
      } else {
        document.getElementById("email error").innerHTML = "";
      }

      // password
      if (pass == "" || pass == null) {
        document.getElementById("pwd error").innerHTML =
          "Please enter your password.aaaa ";
      } else {
        document.getElementById("pwd error").innerHTML = "";
      }
    }

    validation(firstname, lastname, dob, num, mail, pass, repass);

    //first name js
    if (firstname == "" || firstname == null) {
      document.getElementById("fname error").innerHTML =
        "Please enter your first name. aaaa";
      return false;
    } else if (fnamevalid == false) {
      document.getElementById("fname error").innerHTML =
        "Enter Only Character Not Number.aaaaa";
      return false;
    } else {
      document.getElementById("fname error").innerHTML = "";
    }

    //last name js
    if (lastname == "" || lastname == null) {
      document.getElementById("lname error").innerHTML =
        "Please enter your last name.aaaa ";
      return false;
    } else if (lnamevalid == false) {
      document.getElementById("lname error").innerHTML =
        "Enter Only Character Not Number.aaaa";
      return false;
    } else {
      document.getElementById("lname error").innerHTML = "";
    }

    //phone number input js
    if (isNaN(Number(num))) {
      document.getElementById("number error").innerHTML =
        "Please Enter Number Not Character.aaaa";
      return false;
    } else if (phoneregx == false) {
      document.getElementById("number error").innerHTML =
        "Valid Number required.aaaaaa";
      return false;
    } else {
      document.getElementById("number error").innerHTML = "";
    }

    //email input js
    if (emailvalid == false) {
      document.getElementById("email error").innerHTML =
        "Valid Email required.aaaa";
      return false;
    } else {
      document.getElementById("email error").innerHTML = "";
    }

    //password input and match
    if (passwordvalid == false) {
      document.getElementById("pwd error").innerHTML =
        "Set strong password use special character and use 6 character.aaaa";
      return false;
    } else {
      document.getElementById("pwd error").innerHTML = "";
    }

    //confirm password input
    if (repass == "" || repass == null) {
      document.getElementById("repwd error").innerHTML = "Enter Confirm password.aaa";
      return false;
    } else if (pass != repass) {
      document.getElementById("repwd error").innerHTML =
        "Password don't match.aaaaa";
      return false;
    } else {
      document.getElementById("repwd error").innerHTML = "";
    }

    //updated datastore in the local Storage
    var updatedData = {
      Firstname: firstname,
      Lastname: lastname,
      Birthday: dob,
      phonenumber: num,
      email: mail,
      password: pass,
      Gender: document.getElementById("gender").checked ? (gender = "Male") : (gender = "Female"),
    };

    formSubmissions[index] = updatedData;

    localStorage.setItem("formSubmissions", JSON.stringify(formSubmissions));
    var tableRowSelector = `.table_data tr:nth-child(${index + 1})`;
    var tableRow = document.querySelector(tableRowSelector);

    tableRow.innerHTML = `
      <td>${updatedData.Firstname}</td>
      <td>${updatedData.Lastname}</td>
      <td>${updatedData.Gender}</td>
      <td>${updatedData.Birthday}</td>
      <td>${updatedData.phonenumber}</td>
      <td>${updatedData.email}</td>
      <td>${updatedData.password}</td>
      <td>
      <button class="edit-btn" id="editbtn" data-index="${index}">Edit</button>
      &nbsp;
      <input type="button" class="delete-btn" data-index="${index}" value="Delete" /></td>`;
    displayFormSubmissions();
    populateFormForEdit({}, -1);
  });

  //delete / edit button function
  document.addEventListener("click", function (event) {
    if (event.target.classList.contains("edit-btn")) {
      var index = parseInt(event.target.getAttribute("data-index"));
      populateFormForEdit(formSubmissions[index], index);
      document.getElementById("submitbtn").style.display = "none";
    } else if (event.target.classList.contains("delete-btn")) {
      var index = parseInt(event.target.getAttribute("data-index"));
      deleteFormSubmission(index);
      displayFormSubmissions();
    }
  });

  //birthday date cureent is max size till date show
  birthday.max = new Date().toISOString().split("T")[0];

  //update button function
  const updatBtn = document.getElementById("update");
  updatBtn.onclick = () => {
    document.getElementById("submitbtn").style.display = "block";
    document.getElementById("repassword").value = "";
  };
}
displayFormSubmissions();

//clear data 
function cleardata() {
  localStorage.clear();
}

// pagination
const total_records_tr = document.querySelectorAll('.table_data tr');
const records_per_page = 5;
const page_number = 1;
const total_records = total_records_tr.length;
const total_page = Math.ceil(total_records / records_per_page);

generatePage()
displayRecords();
function displayRecords() {
  let start_index = (page_number - 1) * records_per_page;
  let end_index = start_index + (records_per_page - 1);
  let statement = '';
  for (let i = start_index; i <= end_index; i++) {
    statement += `<tr> ${total_records_tr[i].innerHTML} </tr>`;
  }
  recordsDisplay.innerHTML = statement;
  document.querySelectorAll('.dynamic-item').forEach(item=>{
    item.classList.remove('active');
  });
  document.getElementById(`page ${page_number}`).classList.add('active');
}

function generatePage() {
  let prevbtn = `<li class="page-item"><a class="page-link" href="javascript.void(0)" onclick="prevBtn()">Previous</a></li>`;
  
  let nextbtn = `<li class="page-item"><a class="page-link" href="javascript.void(0)" onclick="nextBtn()">Next</a></li>`;
  
  let buttons = '';
  let activeClass = '';
  for (let i = 1; i <= total_page; i++) {
    if (i == 1) {
      activeClass = 'active';
    } else {
      activeClass = '';
    }
    buttons += `<li class="page-item dynamic-item ${activeClass}"><a class="page-link" href="#">${i}</a></li>`;
  }
  document.getElementById('pagination').innerHTML = `${prevbtn} ${button} ${nextbtn}`;
}
function prevBtn() {
  page_number--;
  displayRecords();
}

function nextBtn() {
  page_number++;
  displayRecords();
}