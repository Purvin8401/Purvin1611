function fname() {
  document.getElementById("fname error").innerHTML = "";
}
function lname() {
  document.getElementById("lname error").innerHTML = "";
}
function dob() {
  document.getElementById("dob error").innerHTML = "";
}
function number() {
  document.getElementById("number error").innerHTML = "";
}
function email() {
  document.getElementById("email error").innerHTML = "";
}
function psd() {
  document.getElementById("pwd error").innerHTML = "";
}
function repsd() {
  document.getElementById("repwd error").innerHTML = "";
}