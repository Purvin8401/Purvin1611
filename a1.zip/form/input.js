function fname() {
  document.getElementById("fnamealert").textContent = "";
}
function lname() {
  document.getElementById("lnamealert").textContent = "";
}
function bday() {
  document.getElementById("bdayalert").textContent = "";
}
function number() {
  document.getElementById("numberalert").textContent = "";
}
function email() {
  document.getElementById("emailalert").textContent = "";
}
function psd() {
  document.getElementById("pwdalert").textContent = "";
}
function repsd() {
  document.getElementById("repwdalert").textContent = "";
}
