function validateform(event) {
  event.preventDefault();
  //    first and last name input
  var firstname = document.forminput.inputfname.value.trim();
  let fnameregex = /^[A-Za-z]+$/;
  let fnamevalid = fnameregex.test(firstname);
  var lastname = document.forminput.inputlname.value.trim();
  let lnameregex = /^[A-Za-z]+$/;
  let lnamevalid = lnameregex.test(lastname);

  //   phone number input
  var num = document.forminput.numberinput.value.trim();
  let regex = /^[0-9]{10}$/;

  let phoneregx = regex.test(num);

  //birthday input
  var bday = document.forminput.birthday.value;

  //   email input
  var mail = document.forminput.emailinput.value.trim();
  let emailregex = /^[a-z0-9?.!#$%^&'*+_`~-]+@[a-z]+\.[a-z]+$/;
  let emailvalid = emailregex.test(mail);

  // password input
  var passcode = document.forminput.password.value;
  let passwordregex =
    /^(?=.*[A-Z])(?=.*[a-z])(?=.*[@#$%^&*!])(?=.*[0-9]).{6,15}$/;

  let passwordvalid = passwordregex.test(passcode);

  // repassword input
  let repasscode = document.forminput.repassword.value;

  function cubmit(firstname, lastname, bday, num, mail, passcode) {
    if (firstname == "" || firstname == null) {
      document.getElementById("fnamealert").textContent =
        "Please enter your first name. (This Field is required)22222 ";
    } else {
      document.getElementById("fnamealert").textContent = "";
    }
    if (lastname == "" || lastname == null) {
      document.getElementById("lnamealert").textContent =
        "Please enter your last name. (This Field is required)";
    } else {
      document.getElementById("lnamealert").textContent = "";
    }
    if (bday == "" || bday == null) {
      document.getElementById("bdayalert").textContent =
        "Please enter your Birthday. (This Field is required) ";
    } else {
      document.getElementById("bdayalert").textContent = "";
    }
    if (num == "" || num == null) {
      document.getElementById("numberalert").textContent =
        "Please enter your Phone Number. (This Field is required)";
    } else {
      document.getElementById("numberalert").textContent = "";
    }
    if (mail == "" || mail == null) {
      document.getElementById("emailalert").textContent =
        "Please enter your email. (This Field is required)";
    } else {
      document.getElementById("emailalert").textContent = "";
    }
    if (passcode == "" || passcode == null) {
      document.getElementById("pwdalert").textContent =
        "Please enter your password. (This Field is required)";
    } else {
      document.getElementById("pwdalert").textContent = "";
    }
  }

  cubmit(firstname, lastname, bday, num, mail, passcode, repasscode);

  //   first name js
  if (firstname == "" || firstname == null) {
    document.getElementById("fnamealert").textContent =
      "Please enter your first name. (This Field is required)";
    return false;
  } else if (fnamevalid == false) {
    document.getElementById("fnamealert").textContent =
      "Input Only Character Not Number";
    return false;
  } else {
    document.getElementById("fnamealert").textContent = "";
  }

  //  last name js
  if (lastname == "" || lastname == null) {
    document.getElementById("lnamealert").textContent =
      "Please enter your last name. (This Field is required)";
    return false;
  } else if (lnamevalid == false) {
    document.getElementById("lnamealert").textContent =
      "Input Only Character Not Number";
    return false;
  } else {
    document.getElementById("lnamealert").textContent = "";
  }

  //   phone number input js
  if (isNaN(Number(num))) {
    document.getElementById("numberalert").textContent =
      "Please Enter Number Not Character.";
    return false;
  } else if (phoneregx == false) {
    document.getElementById("numberalert").textContent =
      "Valid Number required";
    return false;
  } else {
    document.getElementById("numberalert").textContent = "";
  }

  //  email input js
  if (emailvalid == false) {
    document.getElementById("emailalert").textContent = "Valid Email required";
    return false;
  } else {
    document.getElementById("emailalert").textContent = "";
  }

  // password input and match
  if (passwordvalid == false) {
    document.getElementById("pwdalert").textContent =
      "Set strong password use special character and use 6 character";
    return false;
  } else {
    document.getElementById("pwdalert").textContent = "";
  }

  //confirm password input
  if (repasscode == "" || repasscode == null) {
    document.getElementById("repwdalert").textContent = "Re-enter password";
    return false;
  } else if (passcode != repasscode) {
    document.getElementById("repwdalert").textContent = "Password don't match";
    return false;
  } else {
    document.getElementById("repwdalert").textContent = "";
  }
  // store data

  function submit() {
    var firstname = document.getElementById("inputfname").value;
    var lastname = document.getElementById("inputlname").value;
    var bday = document.getElementById("birthday").value;
    var num = document.getElementById("numberinput").value;
    var mail = document.getElementById("emailinput").value;
    var passcode = document.getElementById("password").value;
    var Gender = document.getElementById("gender");

    Gender.checked ? (gender = "Male") : (gender = "Female");

    var formSubmissions =
      JSON.parse(localStorage.getItem("formSubmissions")) || [];

    var formData = {
      Firstname: firstname,
      Lastname: lastname,
      Gender: gender,
      Birthday: bday,
      phonenumber: num,
      email: mail,
      password: passcode,
    };

    formSubmissions.push(formData);

    localStorage.setItem("formSubmissions", JSON.stringify(formSubmissions));
    document.getElementById("myForm").reset();
    displayFormSubmissions();
  }
  submit();
}
document.getElementById("myForm").reset();

function displayFormSubmissions() {
  var tabledata = document.querySelector(".table_data");
  var formSubmissions =
    JSON.parse(localStorage.getItem("formSubmissions")) || [];
  var elements = "";

  formSubmissions.map((submission, index) => {
    elements += `<tr>
    <td>${submission.Firstname}</td>
    <td>${submission.Lastname}</td>
    <td>${submission.Gender}</td>
    <td>${submission.Birthday}</td>
    <td>${submission.phonenumber}</td>
    <td>${submission.email}</td>
    <td>${submission.password}</td>
    <td><button class="edit-btn" id="editbtn" data-index="${index}">Edit</button></td>
    <td><input type="button" class="delete-btn" data-index="${index}" value="Delete" /></td>
    </tr>`;
  });
  tabledata.innerHTML = elements;

  function deleteFormSubmission(index) {
    formSubmissions.splice(index, 1);
    localStorage.setItem("formSubmissions", JSON.stringify(formSubmissions));
    displayFormSubmissions();
  }

  function populateFormForEdit(submission, index) {
    document.getElementById("inputfname").value = submission.Firstname || "";
    document.getElementById("inputlname").value = submission.Lastname || "";
    document.getElementById("gender").value = submission.Gender || "";
    document.getElementById("birthday").value = submission.Birthday || "";
    document.getElementById("numberinput").value = submission.phonenumber || "";
    document.getElementById("emailinput").value = submission.email || "";
    document.getElementById("password").value = submission.password || "";

    document.getElementById("update").setAttribute("data-index", index);
  }

  document.getElementById("update").addEventListener("click", function () {
    var index = parseInt(
      document.getElementById("update").getAttribute("data-index")
    );
    var formSubmissions =
      JSON.parse(localStorage.getItem("formSubmissions")) || [];
    //
    //
    //
    var firstname = document.forminput.inputfname.value.trim();
    let fnameregex = /^[A-Za-z]+$/;
    let fnamevalid = fnameregex.test(firstname);
    var lastname = document.forminput.inputlname.value.trim();
    let lnameregex = /^[A-Za-z]+$/;
    let lnamevalid = lnameregex.test(lastname);

    //   phone number input
    var num = document.forminput.numberinput.value.trim();
    let regex = /^[0-9]{10}$/;

    let phoneregx = regex.test(num);

    //birthday input
    var bday = document.forminput.birthday.value;

    //   email input
    var mail = document.forminput.emailinput.value.trim();
    let emailregex = /^[a-z0-9?.!#$%^&'*+_`~-]+@[a-z]+\.[a-z]+$/;
    let emailvalid = emailregex.test(mail);

    // password input
    var passcode = document.forminput.password.value;
    let passwordregex =
      /^(?=.*[A-Z])(?=.*[a-z])(?=.*[@#$%^&*!])(?=.*[0-9]).{6,15}$/;
    let passwordvalid = passwordregex.test(passcode);

    // repassword input
    let repasscode = document.forminput.repassword.value;

    function cubmit(firstname, lastname, bday, num, mail, passcode) {
      if (firstname == "" || firstname == null) {
        document.getElementById("fnamealert").textContent =
          "Please enter your first name. (This Field is required)22222 ";
      } else {
        document.getElementById("fnamealert").textContent = "";
      }
      if (lastname == "" || lastname == null) {
        document.getElementById("lnamealert").textContent =
          "Please enter your last name. (This Field is required)";
      } else {
        document.getElementById("lnamealert").textContent = "";
      }
      if (bday == "" || bday == null) {
        document.getElementById("bdayalert").textContent =
          "Please enter your Birthday. (This Field is required) ";
      } else {
        document.getElementById("bdayalert").textContent = "";
      }
      if (num == "" || num == null) {
        document.getElementById("numberalert").textContent =
          "Please enter your Phone Number. (This Field is required)";
      } else {
        document.getElementById("numberalert").textContent = "";
      }
      if (mail == "" || mail == null) {
        document.getElementById("emailalert").textContent =
          "Please enter your email. (This Field is required)";
      } else {
        document.getElementById("emailalert").textContent = "";
      }
      if (passcode == "" || passcode == null) {
        document.getElementById("pwdalert").textContent =
          "Please enter your password. (This Field is required)";
      } else {
        document.getElementById("pwdalert").textContent = "";
      }
    }

    cubmit(firstname, lastname, bday, num, mail, passcode, repasscode);

    //   first name js
    if (firstname == "" || firstname == null) {
      document.getElementById("fnamealert").textContent =
        "Please enter your first name. (This Field is required)";
      return false;
    } else if (fnamevalid == false) {
      document.getElementById("fnamealert").textContent =
        "Input Only Character Not Number";
      return false;
    } else {
      document.getElementById("fnamealert").textContent = "";
    }

    //  last name js
    if (lastname == "" || lastname == null) {
      document.getElementById("lnamealert").textContent =
        "Please enter your last name. (This Field is required)";
      return false;
    } else if (lnamevalid == false) {
      document.getElementById("lnamealert").textContent =
        "Input Only Character Not Number";
      return false;
    } else {
      document.getElementById("lnamealert").textContent = "";
    }

    //   phone number input js
    if (isNaN(Number(num))) {
      document.getElementById("numberalert").textContent =
        "Please Enter Number Not Character.";
      return false;
    } else if (phoneregx == false) {
      document.getElementById("numberalert").textContent =
        "Valid Number required";
      return false;
    } else {
      document.getElementById("numberalert").textContent = "";
    }

    //  email input js
    if (emailvalid == false) {
      document.getElementById("emailalert").textContent =
        "Valid Email required";
      return false;
    } else {
      document.getElementById("emailalert").textContent = "";
    }

    // password input and match
    if (passwordvalid == false) {
      document.getElementById("pwdalert").textContent =
        "Set strong password use special character and use 6 character";
      return false;
    } else {
      document.getElementById("pwdalert").textContent = "";
    }

    //confirm password input
    if (repasscode == "" || repasscode == null) {
      document.getElementById("repwdalert").textContent = "Re-enter password";
      return false;
    } else if (passcode != repasscode) {
      document.getElementById("repwdalert").textContent =
        "Password don't match";
      return false;
    } else {
      document.getElementById("repwdalert").textContent = "";
    }

    var updatedData = {
      Firstname: firstname,
      Lastname: lastname,
      Birthday: bday,
      phonenumber: num,
      email: mail,
      password: passcode,
      Gender: document.getElementById("gender").checked
        ? (gender = "Male")
        : (gender = "Female"),
    };

    formSubmissions[index] = updatedData;

    localStorage.setItem("formSubmissions", JSON.stringify(formSubmissions));
    var tableRowSelector = `.table_data tr:nth-child(${index + 1})`;
    var tableRow = document.querySelector(tableRowSelector);

    tableRow.innerHTML = `
    <td>${updatedData.Firstname}</td>
    <td>${updatedData.Lastname}</td>
    <td>${updatedData.Gender}</td>
    <td>${updatedData.Birthday}</td>
      <td>${updatedData.phonenumber}</td>
      <td>${updatedData.email}</td>
      <td>${updatedData.password}</td>
      <td><button class="edit-btn" id="editbtn" data-index="${index}">Edit</button></td>
      <td><input type="button" class="delete-btn" data-index="${index}" value="Delete" /></td>
      `;
    displayFormSubmissions();
    populateFormForEdit({}, -1);
  });

  document.addEventListener("click", function (event) {
    if (event.target.classList.contains("edit-btn")) {
      var index = parseInt(event.target.getAttribute("data-index"));
      populateFormForEdit(formSubmissions[index], index);
      document.getElementById("submitbtn").style.display = "none";
    } else if (event.target.classList.contains("delete-btn")) {
      var index = parseInt(event.target.getAttribute("data-index"));
      deleteFormSubmission(index);
      displayFormSubmissions();
    }
  });
  birthday.max = new Date().toISOString().split("T")[0];

  const updatBtn = document.getElementById("update");
  updatBtn.onclick = () => {
    document.getElementById("submitbtn").style.display = "block";
    document.getElementById("repassword").value = "";
  };
}
displayFormSubmissions();
// till date show

function cleardata() {
  localStorage.clear();
}
