function Name_Check() {

    var name = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    const charRegex = /^[a-zA-z]\D/;
    var fnameError = document.getElementById("fnameError");

    if (name.trim() === "") {
        fnameError.innerHTML = "Name cannot be empty";
    } else if (!name.match(charRegex)) {
        fnameError.textContent = 'Please enter only characters for your name.';
    } else {
        fnameError.innerHTML = "";
    }
}

function LName_Check() {
    var lname = document.getElementById("lname").value;

    const charRegex = /\b([A-ZÀ-ÿ][-,a-z. ']+[ ]*)+/;
    var lnameError = document.getElementById("lnameError");
    if (!lname.match(charRegex)) {
        lnameError.textContent = 'Please enter only characters for your name.';
    } else {
        lnameError.innerHTML = "";
    }
    // document.getElementById("required").style.display = "none";

}

function disableSpace(event) {
    var keyCode = event.keyCode ? event.keyCode : event.which;
    if (keyCode === 32) {
        event.preventDefault();
    }
}

function Email_Check() {
    var email = document.getElementById("Email").value;
    var emailError = document.getElementById("emailError");
    var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (email.trim() === "") {
        emailError.innerHTML = "Email cannot be empty";
    } else if (!emailRegex.test(email)) {
        emailError.innerHTML = "Invalid email format";
    } else {
        emailError.innerHTML = "";
    }
}

function Password_Check() {
    var password = document.getElementById("Pwd").value;
    var confirmPassword = document.getElementById("ConfirmPwd").value;
    var passwordError = document.getElementById("passwordError");
    var confirmPasswordError = document.getElementById("confirmPasswordError");
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z])(?!.*\s).{8,}$/;

    if (password.trim() === "") {
        passwordError.innerHTML = "Password cannot be empty";
    } else if (password.includes(" ")) {
        passwordError.innerHTML = "Password cannot contain spaces";
    } else if (!password.match(passwordRegex)) {
        passwordError.textContent = 'Password must be at least 8 characters long and contain at least one digit, one lowercase letter, and one uppercase letter. And Space not allowed';
    } else {
        passwordError.innerHTML = "";
    }

    if (password !== confirmPassword) {
        confirmPasswordError.textContent = "Passwords do not match.";
    } else {
        confirmPasswordError.textContent = "";
    }
}

function ConfirmPassword_Check() {
    var password = document.getElementById("Pwd").value;
    var confirmPassword = document.getElementById("ConfirmPwd").value;
    var confirmPasswordError = document.getElementById("confirmPasswordError");
    if (password !== confirmPassword) {
        confirmPasswordError.textContent = "Passwords do not match.";
    } else {
        confirmPasswordError.textContent = "";
    }
    Password_Check();
}

function Date_Check() {
    var dob = document.getElementById('dob').value;
    var dobError = document.getElementById("dobError");

    if (dob.trim() === "") {
        dobError.textContent = "Date of birth cannot be empty";
        return;
    }
}

function Mobile_Check() {
    var mobileNumber = document.getElementById("mobileNumber").value;
    var mobileNumberError = document.getElementById("mobileNumberError");
    var mobileRegex = /^\d{10}$/;
    if (mobileNumber.trim() === "") {
        mobileNumberError.innerHTML = "Mobile number cannot be empty";
    } else if (!mobileRegex.test(mobileNumber)) {
        mobileNumberError.innerHTML = "Invalid mobile number";
    } else {
        mobileNumberError.innerHTML = "";
    }
}

function disableAlphabets(event) {
    var keyCode = event.keyCode ? event.keyCode : event.which;
    if (keyCode <= 57 && keyCode >= 48) {
        return;
    }
    else {
        event.preventDefault();
    }
}

function validateForm() {
    var isValid = true;
    var fname = document.getElementById("fname").value.trim();
    var lname = document.getElementById("lname").value.trim();
    var email = document.getElementById("Email").value.trim();
    var password = document.getElementById("Pwd").value.trim();
    var confirmPassword = document.getElementById("ConfirmPwd").value.trim();
    var mobileNumber = document.getElementById("mobileNumber").value.trim();

    // error
    var fnameError = document.getElementById("fnameError");
    var lnameError = document.getElementById("lnameError");
    var emailError = document.getElementById("emailError");
    var passwordError = document.getElementById("passwordError");
    var confirmPasswordError = document.getElementById("confirmPasswordError");
    var mobileNumberError = document.getElementById("mobileNumberError");

// fname and lname
    if (fname === "") {
        fnameError.innerHTML = "Name cannot be empty";
        isValid = false;
    } else {
        fnameError.innerHTML = "";
    }

    // email
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === "") {
        emailError.innerHTML = "Email cannot be empty";
        isValid = false;
    } else if (!emailRegex.test(email)) {
        emailError.innerHTML = "Invalid email format";
        isValid = false;
    } else {
        emailError.innerHTML = "";
    }

    // password
    if (password === "") {
        passwordError.innerHTML = "Password cannot be empty";
        isValid = false;
    } else if (password.includes(" ")) {
        passwordError.innerHTML = "Password cannot contain spaces";
        isValid = false;
    } else {
        passwordError.innerHTML = "";
    }

    // confirm password
    if (password !== confirmPassword) {
        confirmPasswordError.textContent = "Passwords do not match.";
        isValid = false;
    } else {
        confirmPasswordError.innerHTML = "";
    }

    // mobile number
    var mobileRegex = /^\d{10}$/;
    if (mobileNumber === "") {
        mobileNumberError.innerHTML = "Mobile number cannot be empty";
        isValid = false;
    } else if (!mobileRegex.test(mobileNumber)) {
        mobileNumberError.innerHTML = "Invalid mobile number";
        isValid = false;
    } else {
        mobileNumberError.innerHTML = "";
    }
    return isValid;
}