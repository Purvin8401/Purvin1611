var storedData = JSON.parse(localStorage.getItem("formData")) || [];

function SUBMIT() {
    Name_Check();
    Email_Check();
    Password_Check();
    ConfirmPassword_Check();
    Mobile_Check();
    Date_Check();
    var isValid = validateForm();
    if (isValid) {
        storeData();
    }
}

function storeData() {
    const fname = document.getElementById('fname').value;
    const lname = document.getElementById('lname').value;
    const email = document.getElementById('Email').value.toLowerCase();
    const password = document.getElementById('Pwd').value;
    const mobileNumber = document.getElementById('mobileNumber').value;
    const date = document.getElementById('dob').value;
    const genderElement = document.querySelector('input[name="gender"]:checked');
    const gender = genderElement ? genderElement.value : null;


    var storedData = JSON.parse(localStorage.getItem("formData")) || [];
    
    console.log(storeData)
    var DuplicateEmail = storedData.some(function (user) {
        return user.email === email;
    });

    if (DuplicateEmail) {
        alert("This email already exists. Please use a different email address.");
        return;
    }

    var formData = {
        fname: fname,
        lname: lname,
        date: date,
        gender: gender,
        mobileNumber: mobileNumber,
        email: email,
        password: password,
    };

    storedData.push(formData);
    localStorage.setItem("formData", JSON.stringify(storedData));
    console.log("1" + storedData)
    reset();

}

function fillForm(email) {
    var storedData = JSON.parse(localStorage.getItem("formData")) || [];
    const index = storedData.findIndex(item => item.email === email);
    console.log(index);
    const updateButtons = document.querySelectorAll('[id^="UpdateButton"]');
    updateButtons.forEach(button => {
        button.disabled = true;
    });

    document.getElementById(`DeleteButton${email}`).style.display = 'none';
    document.getElementById(`UpdateButton${email}`).style.display = 'none';

    var data = storedData[index];
    console.log(data.gender)
    document.getElementById("fname").value = data.fname;
    document.getElementById("lname").value = data.lname;
    document.getElementById(data.gender).checked = true;
    document.getElementById("dob").value = data.date;
    document.getElementById("mobileNumber").value = data.mobileNumber;
    document.getElementById("Email").value = data.email;
    document.getElementById("Pwd").value = data.password;
    document.getElementById("ConfirmPwd").value = data.password;
    document.getElementById("currentIndex").value = index;
}

function saveData() {
    var index = document.getElementById("currentIndex").value;
    const fname = document.getElementById('fname').value;
    const lname = document.getElementById('lname').value;
    var email = document.getElementById('Email').value;
    const password = document.getElementById('Pwd').value;
    const mobileNumber = document.getElementById('mobileNumber').value;
    const date = document.getElementById('dob').value;
    const genderElement = document.querySelector('input[name="gender"]:checked');
    const gender = genderElement ? genderElement.value : null;
    
    var storedData = JSON.parse(localStorage.getItem("formData")) || [];

    var formData = {
        fname: fname,
        lname: lname,
        email: email,
        password: password,
        mobileNumber: mobileNumber,
        date: date,
        gender: gender,
    };

    storedData[index] = formData;
    localStorage.setItem("formData", JSON.stringify(storedData));
    reset();
    var storedData = JSON.parse(localStorage.getItem("formData")) || [];
}