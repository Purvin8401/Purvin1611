function form(e) {
    e.preventDefault();
  
    //first and last name
    var firstname = document.forminput.fname.value.trim();
    var lastname = document.forminput.lname.value.trim();
    let Gender = document.forminput.gender.value;
    let bday = document.forminput.birthday.value;
    let num = document.forminput.number.value.trim();
    let mail = document.forminput.email.value.trim();
    let pass = document.forminput.password.value;
    let repass = document.forminput.repassword.value;
  
    //firstname
    if (firstname == "" || firstname == null) {
      document.getElementById('fnameerror').textContent = "Input First Name";
      return false;
    } else if (!/^[A-Za-z]+$/.test(firstname)) {
      document.getElementById('fnameerror').textContent = "Fastname should only contain alphabates";
      return false;
    } else {
      document.getElementById('fnameerror').textContent = "";
    }
  
    //lastname
    if (lastname == "" || lastname == null) {
      document.getElementById('lnameerror').textContent = "Input First Name";
    } else if (!/^[A-Za-z]+$/.test(lastname)) {
      document.getElementById('lnameerror').textContent = "Lastname should only contain alphabates";
      return false;
    } else {
      document.getElementById('lnameerror').textContent = "";
    }
  
    //phone number
    if (num == null || num == "") {
      document.getElementById('numerror').textContent = "Please provide your Mobile Number";
      return false;
    } else if (/^\[0-9]{10}$/.test(num)) {
      document.getElementById('numerror').textContent = "Please  Enter a valid mobile number in 10 Digits";
      return false;
    } else {
      document.getElementById('numerror').textContent = "";
    }
  
    //email
    if (mail == "" || mail == null || !mail.includes('@')) {
      document.getElementById('emailerror').textContent = "please provide an email address";
      return false;
    } else {
      document.getElementById('emailerror').textContent = "";
    }
  
    // password
    if (pass == "" || pass == null) {
      document.getElementById('pwderror').textContent = "Please provide a password";
      return false;
    } else if (pass != repass) {
      document.getElementById('repwderror').textContent = "Passwords do not match.";
      return false;
    } else {
      document.getElementById('pwderror').textContent = "";
      document.getElementById('repwderror').textContent = "";
    }
  
    // local storage
    Gender.checked ? (gender = "Male") : (gender = "Female");
  
  }

  birthday.max = new Date().toISOString().split("T")[0];
  
  // function resetitem() {
  //   let show = document.getElementById("showdata");
  //   show.style.display = "none";
  // }
  
  /*function hideitem() {
    let showitems = document.getElementById("showdata");
    showitems.style.display = "none";
    let hideitems = document.getElementById("Hide");
    hideitems.style.display = "none";
  }*/
  // function cleardata() {
  //   localStorage.clear();
  // }