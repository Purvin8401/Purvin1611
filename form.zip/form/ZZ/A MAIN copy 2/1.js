function validateForm() {
    var isValid = true;
    var fname = document.getElementById("fname").value.trim();
    var lname = document.getElementById("lname").value.trim();
    var email = document.getElementById("email").value.trim();
    var password = document.getElementById("pass").value.trim();
    var repass = document.getElementById("repass").value.trim();
    var number = document.getElementById("number").value.trim();

    // error
    var fnameerror = document.getElementById('fnameerror');
    var lnameerror = document.getElementById("lnameerror");
    var emailerror = document.getElementById("emailerror");
    var numerror = document.getElementById("numerror");
    var pwderror = document.getElementById("pwderror");
    var repwderror = document.getElementById("repwderror");

    // fname
    if (fname == "") {
        fnameerror.innerHTML = "Name cannot be empty";
        isValid = false;
    } else {
        fnameerror.innerHTML = "";
    }
    
    // lname
    if (lname == "") {
        lnameerror.innerHTML = "Name cannot be empty";
        isValid = false;
    } else {
        lnameerror.innerHTML = "";
    }

    // mobile number
    var mobileRegex = /^\d{10}$/;
    if (number == "") {
        numerror.innerHTML = "Mobile number cannot be empty";
        isValid = false;
    } else if (!mobileRegex.test(number)) {
        numerror.innerHTML = "Invalid mobile number";
        isValid = false;
    } else {
        numerror.innerHTML = "";
    }

    // email
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email == "") {
        emailerror.innerHTML = "Email cannot be empty";
        isValid = false;
    } else if (!emailRegex.test(email)) {
        emailerror.innerHTML = "Invalid email format";
        isValid = false;
    } else {
        emailerror.innerHTML = "";
    }

    // password
    if (pass == "") {
        pwderror.innerHTML = "Password cannot be empty";
        isValid = false;
    } else if (pass.includes(" ")) {
        pwderror.innerHTML = "Password cannot contain spaces";
        isValid = false;
    } else {
        pwderror.innerHTML = "";
    }

    // confirm password
    if (pass !== repass) {
        repwderror.textContent = "Passwords do not match.";
        isValid = false;
    } else {
        repwderror.innerHTML = "";
    }
    return isValid;
}
/*function validateForm(event) {
    event.preventDefault();

//     var isValid = true;
    var fname = document.getElementById("fname").value.trim();
    var lname = document.getElementById("lname").value.trim();
    var email = document.getElementById("email").value.trim();
    var pass = document.getElementById("pass").value.trim();
    var repass = document.getElementById("repass").value.trim();
    var number = document.getElementById("number").value.trim();

    // error
    var fnameerror = document.getElementById('fnameerror');
    var lnameerror = document.getElementById("lnameerror");
    var emailerror = document.getElementById("emailerror");
    var numerror = document.getElementById("numerror");
    var pwderror = document.getElementById("pwderror");
    var repwderror = document.getElementById("repwderror");

    // fname
    if (fname == "") {
        fnameerror.innerHTML = "Name cannot be empty";
        isValid = false;
    } else {
        fnameerror.innerHTML = "";
    }
    
    // lname
    if (lname == "") {
        lnameerror.innerHTML = "Name cannot be empty";
        isValid = false;
    } else {
        lnameerror.innerHTML = "";
    }

//     // mobile number
    var mobileRegex = /^\d{10}$/;
    if (number == "") {
        numerror.innerHTML = "Mobile number cannot be empty";
        isValid = false;
    } else if (!mobileRegex.test(number)) {
        numerror.innerHTML = "Invalid mobile number";
        isValid = false;
    } else {
        numerror.innerHTML = "";
    }

//     // email
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email == "") {
        emailerror.innerHTML = "Email cannot be empty";
        isValid = false;
    } else if (!emailRegex.test(email)) {
        emailerror.innerHTML = "Invalid email format";
        isValid = false;
    } else {
        emailerror.innerHTML = "";
    }

//     // password
    if (pass == "") {
        pwderror.innerHTML = "Password cannot be empty";
        isValid = false;
    } else if (pass.includes(" ")) {
        pwderror.innerHTML = "Password cannot contain spaces";
        isValid = false;
    } else {
        pwderror.innerHTML = "";
    }

//     // confirm password
    if (pass !== repass) {
        repwderror.textContent = "Passwords do not match.";
        isValid = false;
    } else {
        repwderror.innerHTML = "";
    }
//     return isValid;
 }*/

     /*// Clear the form
    document.getElementById('fname').value = '';
    document.getElementById('lname').value = '';
    document.querySelector('input[name="gender"]:checked').checked = false;
    document.getElementById('birthday').value = '';
    document.querySelector('input[name="number"]').value = '';
    document.getElementById('email').value = '';
    document.querySelector('input[name="password"]').value = '';
    document.querySelector('input[name="repassword"]').value = '';*/