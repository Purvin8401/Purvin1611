function submit() {
    fn_check();
    ln_check();
    phn_check();
    em_check();
    pass_check();
    repass_check();
    Date_Check();
    gender_check();
}

// Retrieve the data from local storage and display it in the table
function retrieveData() {
    var data = JSON.parse(localStorage.getItem('data')) || [];
    var tbody = document.querySelector('#data-table tbody');

    tbody.innerHTML = '';

    data.forEach(function (item) {
        var row = document.createElement('tr');
        var fnameCell = document.createElement('td');
        var lnameCell = document.createElement('td');
        var emailCell = document.createElement('td');
        var gendercell = document.createElement('td');
        var birthdaycell = document.createElement('td');
        var phonecell = document.createElement('td');
        var emailCell = document.createElement('td');
        var passCell = document.createElement('td');
        var actionsCell = document.createElement('td');


        fnameCell.textContent = item.fname;
        lnameCell.textContent = item.lname;
        emailCell.textContent = item.email;
        gendercell.textContent = item.gender;
        birthdaycell.textContent = item.birthday;
        phonecell.textContent = item.phone;
        emailCell.textContent = item.email;
        passCell.textContent = item.pass;

        
        // edit a delete button
        var editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.onclick = function () {
            editData(item.id);
        };

        actionsCell.appendChild(editButton);

        // Create a delete button
        var deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = function () {
            deleteData(item.id);
        };

        actionsCell.appendChild(deleteButton);

        row.appendChild(fnameCell);
        row.appendChild(lnameCell);
        row.appendChild(emailCell);
        row.appendChild(gendercell);
        row.appendChild(birthdaycell);
        row.appendChild(phonecell);
        row.appendChild(emailCell);
        row.appendChild(passCell);
        row.appendChild(actionsCell);

        tbody.appendChild(row);

    });
}

// Edit a row
function editData(id) {
    var data = JSON.parse(localStorage.getItem('data')) || [];
    var index = data.findIndex(function (item) {
      return item.id === id;
    });
  
    if (index!== -1) {
      // Update the form fields with the retrieved data
      document.getElementById('fname').value = data[index].fname;
      document.getElementById('lname').value = data[index].lname;
      document.getElementById('gender').value = data[index].gender;
      document.getElementById('birthday').value = data[index].birthday;
      document.getElementById('number').value = data[index].phone;
      document.getElementById('email').value = data[index].email;
      document.getElementById('pass').value = data[index].pass;

      // Set the id of the row to be edited
      document.getElementById('edit-id').value = id;
      // Set the action of the form to be "edit"
      document.getElementById('form').action = 'edit';
      
      // Call the storeData() function to update the data in local storage
    //   storeData();
    }
  }

//   document.getElementById('update').addEventListener('click', function () {
//     updateData();
//   });
  function updateData() {
    // Get the values from the form
    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var gender = document.querySelector('input[name="gender"]:checked').value;
    var birthday = document.getElementById('birthday').value;
    var phone = document.querySelector('input[name="number"]').value;
    var email = document.getElementById('email').value;
    var pass = document.querySelector('input[name="password"]').value;
  
    // Get the data from local storage
    var data = JSON.parse(localStorage.getItem('data')) || [];
  
    // Find the index of the item to be updated
    var index = data.findIndex(function (item) {
      return item.id === parseInt(document.getElementById('edit-id').value);
    });
  
    if (index!== -1) {
      // Update the item in the data array
      data[index] = { id: data[index].id, fname: fname, lname: lname, gender: gender, birthday: birthday, phone: phone, email: email, pass: pass };
  
      // Update the local storage
      localStorage.setItem('data', JSON.stringify(data));
  
      // Display the updated data in the table
      retrieveData();
    }
  }

// Initialize a counter variable
var counter = 0;


// Store the data in local storage
function storeData(e) {
    // e.preventDefault();

    // Get the values from the form
    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var gender = document.querySelector('input[name="gender"]:checked').value;
    var birthday = document.getElementById('birthday').value;
    var phone = document.querySelector('input[name="number"]').value;
    var email = document.getElementById('email').value;
    var pass = document.querySelector('input[name="password"]').value;


    // Check if the email already exists

    var data = JSON.parse(localStorage.getItem('data')) || [];
    var index = data.findIndex(function () {
        return ;
        // return item.email === email;
    });
    if (index === -1) {
        data.push({ id: counter, fname: fname, lname: lname, gender: gender, birthday: birthday, phone: phone, email: email, pass: pass });
        localStorage.setItem('data', JSON.stringify(data));
        return counter++;
    } else {
        document.getElementById('error').innerHTML = '';
        document.getElementById('error').style.color = 'red';
        return;
    }
}

// Delete the data from local storage
function deleteData(id) {
    var data = JSON.parse(localStorage.getItem('data')) || [];
    var index = data.findIndex(function (item) {
        return item.id === id;
    });
    if (index !== -1) {
        data.splice(index, 1);
        localStorage.setItem('data', JSON.stringify(data));
        retrieveData();
    }
}


document.getElementById('myForm').reset();

// Add an event listener to the form
document.getElementById('myForm').addEventListener('submit', function (e) {
    e.preventDefault();
    submit();
    // Store the data in local storage
    storeData();

    // Display the data in the table
    retrieveData();
});

function clearitem() {
    localStorage.clear();
}