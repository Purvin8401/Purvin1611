//fname
function fn_check() {
    var fname = document.getElementById("fname").value;
    const charRegex = /^[a-zA-z]\D/;
    var fnameerror = document.getElementById("fnameerror");

    if (fname.trim() === "") {
        fnameerror.innerHTML = "Name cannot be empty";
    } else if (!fname.match(charRegex)) {
        fnameerror.textContent = 'Please enter only characters for your First name.';
    } else {
        fnameerror.innerHTML = "";
    }
    return;
}

//lname
function ln_check() {
    var lname = document.getElementById("lname").value;
    const charRegex = /^[a-zA-z]\D/;
    var lnameerror = document.getElementById("lnameerror");

    if (lname.trim() === "") {
        lnameerror.innerHTML = "Last Name cannot be empty";
    } else if (!lname.match(charRegex)) {
        lnameerror.textContent = 'Please enter only characters for your Last name.';
    } else {
        lnameerror.innerHTML = "";
    }
    return;
}

//phone
function phn_check() {
    var number = document.getElementById("number").value;
    var numerror = document.getElementById("numerror");
    var mobileRegex = /^\d{10}$/;
    if (number.trim() === "") {
        numerror.innerHTML = "Mobile number cannot be empty";
    } else if (!mobileRegex.test(number)) {
        numerror.innerHTML = "Invalid mobile number";
    } else {
        numerror.innerHTML = "";
    }
    return;
}

//email
function em_check() {
    var email = document.getElementById("email").value;
    var emailerror = document.getElementById("emailerror");
    var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.]+\.[a-zA-Z]{2,}$/;
    if (email.trim() === "") {
        emailerror.innerHTML = "Email cannot be empty";
    } else if (!emailRegex.test(email)) {
        emailerror.innerHTML = "Invalid email format";
    } else {
        emailerror.innerHTML = "";
    }
    return;
}

//pass
function pass_check() {
    var password = document.getElementById("pass").value;
    var pwderror = document.getElementById("pwderror");
    // const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z])(?!.*\s).{3,}$/;
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{1,}$/;


    if (password.trim() === "") {
        pwderror.innerHTML = "Password cannot be empty";
    } else if (password.includes(" ")) {
        pwderror.innerHTML = "Password cannot contain spaces";
    } else if (!password.match(passwordRegex)) {
        pwderror.textContent = "Password must be at least 8 characters long and contain at least one digit, one lowercase letter, and one uppercase letter. And Space not allowed";
    } else {
        pwderror.innerHTML = "";
    }
    return;
}

//repass
function repass_check() {
    var password = document.getElementById("pass").value;
    var repassword = document.getElementById("repass").value;
    if (password != repassword) {
        repwderror.textContent = "Passwords do not match.";
    } else {
        repwderror.textContent = "";
    }
    return;
}

//date
function Date_Check() {
    var dob = document.getElementById('birthday').value;
    var doberror = document.getElementById("dobError");

    if (dob.trim() === "") {
        doberror.textContent = "Date of birth cannot be empty";
        return;
    }
}

// Add gender validation here
function gender_check() {
    var gender = document.querySelector('input[name="gender"]:checked');
    if (!gender) {
        document.getElementById('gendererror').innerHTML = 'Please select a gender.';
        return;
    } else {
        document.getElementById('gendererror').innerHTML = '';
    }
    return;
}

birthday.max = new Date().toISOString().split("T")[0];

//reset Button
function resetbtn() {
    document.getElementById('fnameerror').innerHTML = '';
    document.getElementById('lnameerror').innerHTML = '';
    document.getElementById('gendererror').innerHTML = '';
    document.getElementById('doberror').innerHTML = '';
    document.getElementById('numerror').innerHTML = '';
    document.getElementById('emailerror').innerHTML = '';
    document.getElementById('pwderror').innerHTML = '';
    document.getElementById('repwderror').innerHTML = '';
    document.getElementById('error').innerHTML = '';
}