// submit
function submit(){
    fn_check()
    ln_check()
    phn_check()
    em_check()
    pass_check()
    Date_Check()
    storeData()
}

// Retrieve the data from local storage and display it in the table
function retrieveData() {
    var data = JSON.parse(localStorage.getItem('data')) || [];
    var tbody = document.querySelector('#data-table tbody');

    tbody.innerHTML = '';

    data.forEach(function (item) {
        var row = document.createElement('tr');
        var fnameCell = document.createElement('td');
        var lnameCell = document.createElement('td');
        var emailCell = document.createElement('td');
        var gendercell = document.createElement('td');
        var birthdaycell = document.createElement('td');
        var phonecell = document.createElement('td');
        var emailCell = document.createElement('td');
        var passCell = document.createElement('td');
        var actionsCell = document.createElement('td');


        fnameCell.textContent = item.fname;
        lnameCell.textContent = item.lname;
        emailCell.textContent = item.email; gendercell.textContent = item.gender;
        birthdaycell.textContent = item.birthday;
        phonecell.textContent = item.phone;
        emailCell.textContent = item.email;
        passCell.textContent = item.pass;

        // Create a delete button
        var deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = function () {
            deleteData(item.id);
        };

        // edit a delete button
        var editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.onclick = function () {
            editData(item.id);
        };

        actionsCell.appendChild(deleteButton);

        row.appendChild(fnameCell);
        row.appendChild(lnameCell);
        row.appendChild(emailCell);
        row.appendChild(gendercell);
        row.appendChild(birthdaycell);
        row.appendChild(phonecell);
        row.appendChild(emailCell);
        row.appendChild(passCell);
        row.appendChild(actionsCell);

        tbody.appendChild(row);
    });
}


// Initialize a counter variable
var counter = 0;

// Store the data in local storage
function storeData() {
    
    // Get the values from the form

    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var gender = document.getElementById('gender').value;
    var dob = document.getElementById('dob').value;
    var phone = document.getElementById('number').value;
    var email = document.getElementById('email').value;
    var pass = document.getElementById('password').value;

    // Check if the email already exists

    var data = JSON.parse(localStorage.getItem('data')) || [];
    var index = data.findIndex(function (item) {
        return item.email === email;
    });
    if (index === -1) {
        data.push({ id: counter, fname: fname, lname: lname, gender: gender, dob: dob, phone: phone, email: email, pass: pass });
        localStorage.setItem('data', JSON.stringify(data));
        return counter++;
    } else {
        document.getElementById('error').innerHTML = '';
        document.getElementById('error').style.color = 'red';
        return;
    }
}

// Delete the data from local storage
function deleteData(id) {
    var data = JSON.parse(localStorage.getItem('data')) || [];
    var index = data.findIndex(function (item) {
        return item.id === id;
    });
    if (index !== -1) {
        data.splice(index, 1);
        localStorage.setItem('data', JSON.stringify(data));
        retrieveData();
    }
}

// Add an event listener to the form
document.getElementById('myForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // submit function called
    submit();
    
    // Store the data in local storage
    storeData();
    
    // Clear the form
    document.getElementById('fname').value = '';
    document.getElementById('lname').value = '';
    document.getElementById('gender').value= '';
    document.getElementById('dob').value = '';
    document.getElementById('number').value = '';
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';
    document.getElementById('repassword').value = '';

    // Display the data in the table
    retrieveData();
});