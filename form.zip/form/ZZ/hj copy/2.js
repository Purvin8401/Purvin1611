// Retrieve the data from local storage and display it in the table
function retrieveData() {
    var data = JSON.parse(localStorage.getItem('data')) || [];
    var tbody = document.querySelector('#data-table tbody');

    tbody.innerHTML = '';

    data.forEach(function (item) {
        var row = document.createElement('tr');
        var fnameCell = document.createElement('td');
        var lnameCell = document.createElement('td');
        var emailCell = document.createElement('td');
        var gendercell = document.createElement('td');
        var birthdaycell = document.createElement('td');
        var phonecell = document.createElement('td');
        var emailCell = document.createElement('td');
        var passCell = document.createElement('td');
        var actionsCell = document.createElement('td');


        fnameCell.textContent = item.fname;
        lnameCell.textContent = item.lname;
        emailCell.textContent = item.email; 
        gendercell.textContent = item.gender;
        birthdaycell.textContent = item.birthday;
        phonecell.textContent = item.phone;
        emailCell.textContent = item.email;
        passCell.textContent = item.pass;

        // Create a delete button
        var deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = function () {
            deleteData(item.id);
        };

        actionsCell.appendChild(deleteButton);

        row.appendChild(fnameCell);
        row.appendChild(lnameCell);
        row.appendChild(emailCell);
        row.appendChild(gendercell);
        row.appendChild(birthdaycell);
        row.appendChild(phonecell);
        row.appendChild(emailCell);
        row.appendChild(passCell);
        row.appendChild(actionsCell);

        tbody.appendChild(row);
    });
}


// Initialize a counter variable
var counter = 0;

// Store the data in local storage
function storeData() {

    // Get the values from the form

    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var gender = document.getElementById('gender').value;
    var birthday = document.getElementById('birthday').value;
    var phone = document.getElementById('number').value;
    var email = document.getElementById('email').value;
    var pass = document.getElementById('password').value;

    fn_check();
    ln_check();
    Date_Check();
    phn_check();
    em_check();
    pass_check();
}

// Delete the data from local storage
function deleteData(id) {
    var data = JSON.parse(localStorage.getItem('data')) || [];
    var index = data.findIndex(function (item) {
        return item.id === id;
    });
    if (index !== -1) {
        data.splice(index, 1);
        localStorage.setItem('data', JSON.stringify(data));
        retrieveData();
    }
}

// Add an event listener to the form
document.getElementById('myForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // Store the data in local storage
    storeData();

    // Clear the form
    document.getElementById('fname').value = '';
    document.getElementById('lname').value = '';
    document.getElementById('gender').value = '';
    document.getElementById('birthday').value = '';
    document.getElementById('number').value = '';
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';
    document.getElementById('repassword').value = '';
    // Display the data in the table
    retrieveData();
});