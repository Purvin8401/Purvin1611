function fn_check() {
    var fname = document.getElementById("fname").value;
    const charRegex = /^[a-zA-z]\D/;
    var fnameerror = document.getElementById("fnameerror");

    if (fname.trim() === "") {
        fnameerror.innerHTML = "Name cannot be empty";
    } else if (!fname.match(charRegex)) {
        fnameerror.textContent = 'Please enter only characters for your First name.';
    } else {
        fnameerror.innerHTML = "";
    }
}

function ln_check() {
    var lname = document.getElementById("lname").value;
    const charRegex = /^[a-zA-z]\D/;
    var lnameerror = document.getElementById("lnameerror");

    if (lname.trim() === "") {
        lnameerror.innerHTML = "Last Name cannot be empty";
    } else if (!lname.match(charRegex)) {
        lnameerror.textContent = 'Please enter only characters for your Last name.';
    } else {
        lnameerror.innerHTML = "";
    }
}

function phn_check() {
    var number = document.getElementById("number").value;
    var numerror = document.getElementById("numerror");
    var mobileRegex = /^\d{10}$/;
    if (number.trim() === "") {
        numerror.innerHTML = "Mobile number cannot be empty";
    } else if (!mobileRegex.test(number)) {
        numerror.innerHTML = "Invalid mobile number";
    } else {
        numerror.innerHTML = "";
    }
}

function em_check() {
    var email = document.getElementById("email").value;
    var emailerror = document.getElementById("emailerror");
    var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.]+\.[a-zA-Z]{2,}$/;
    if (email.trim() === "") {
        emailerror.innerHTML = "Email cannot be empty";
    } else if (!emailRegex.test(email)) {
        emailerror.innerHTML = "Invalid email format";
    } else {
        emailerror.innerHTML = "";
    }
}

function pass_check() {
    var password = document.getElementById("pass").value;
    var pwderror = document.getElementById("pwderror");
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z])(?!.*\s).{8,}$/;

    if (password.trim() === "") {
        pwderror.innerHTML = "Password cannot be empty";
    } else if (password.includes(" ")) {
        pwderror.innerHTML = "Password cannot contain spaces";
    } else if (!password.match(passwordRegex)) {
        pwderror.textContent = "Password must be at least 8 characters long and contain at least one digit, one lowercase letter, and one uppercase letter. And Space not allowed";
    } else {
        pwderror.innerHTML = "";
    }

}

function repass_check(){
    var password = document.getElementById("pass").value;
    var repassword = document.getElementById("repass").value;
    if (password != repassword) {
        repwderror.textContent = "Passwords do not match.";
    } else {
        repwderror.textContent = "";
    }
}

function Date_Check() {
    var dob = document.getElementById('birthday').value;
    var doberror = document.getElementById("dobError");

    if (dob.trim() === "") {
        doberror.textContent = "Date of birth cannot be empty";
        return;
    }
}

// function submit(){
//     fn_check()
//     ln_check()
//     phn_check()
//     em_check()
//     pass_check()
//     repass_check()
//     Date_Check()
// }