function validateform(event) {
  event.preventDefault();
  //    first and last name input
  var firstname = document.forminput.inputfname.value.trim();
  var lastname = document.forminput.inputlname.value.trim();

  //   phone number input
  let num = document.forminput.numberinput.value.trim();
  let regex = /^\+91[0-9]{10}$/;

  let phoneregx = regex.test(num);

  //gender input
  let Gender = document.getElementById("gender");

  //birthday input
  let bday = document.forminput.birthday.value;

  //   email input
  let mail = document.forminput.emailinput.value.trim();
  let emailregex = /^[a-z0-9?!#$%^&'*+_`~-]+@(?:email|gmail)\.(?:com|in)$/;
  let emailvalid = emailregex.test(mail);

  // password input
  let passcode = document.forminput.password.value;
  let passwordregex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])\w{6,100}$/;
  let passwordvalid = passwordregex.test(passcode);

  // repassword input
  let repasscode = document.forminput.repassword.value;

  //   first and last name js
  if (firstname == "" || firstname == null) {
    alert("Input First Name");
    return false;
  } else if (!isNaN(Number(firstname))) {
    alert("Input1 Only Character");
    return false;
  } else if (lastname == "" || lastname == null) {
    alert("Input Last Name");
  } else if (!isNaN(Number(lastname))) {
    alert("Input2 Only Character");
    return false;
  }

  //   phone number input js
  if (isNaN(Number(num))) {
    alert("Input valid number");
    return false;
  } else if (phoneregx == false) {
    alert("Input Valid number");
    return false;
  }

  //  email input js
  if (emailvalid == false) {
    alert("Input valid email");
    return false;
  }

  // password input and match
  if (passwordvalid == false) {
    alert("Set strong password and use 6 char");
    return false;
  }

  //confirm password input
  if (passcode != repasscode) {
    alert("Password don't match");
    return false;
  }
  // local storage
  Gender.checked ? (gender = "Male") : (gender = "Female");

  localStorage.setItem("Firstname", firstname);
  localStorage.setItem("Lastname", lastname);
  localStorage.setItem("Gender", gender);
  localStorage.setItem("Birthday", bday);
  localStorage.setItem("Phone_Number", num);
  localStorage.setItem("Mail_Id", mail);
  localStorage.setItem("Password", passcode);

  // localStorage.removeItem("Password");
}

// till date show
birthday.max = new Date().toISOString().split("T")[0];

// local storage to get item
function showitem() {
  let h = document.getElementById("showdata");
  h.style.display = "block";
  let p = document.getElementById("Hide");
  p.style.display = "block";

  document.getElementById("demo1").innerHTML =
    localStorage.getItem("Firstname");
  document.getElementById("demo2").innerHTML = localStorage.getItem("Lastname");
  document.getElementById("demo3").innerHTML = localStorage.getItem("Gender");
  document.getElementById("demo4").innerHTML = localStorage.getItem("Birthday");
  document.getElementById("demo5").innerHTML =
    localStorage.getItem("Phone_Number");
  document.getElementById("demo6").innerHTML = localStorage.getItem("Mail_Id");
}
function resetitem() {
  let h = document.getElementById("showdata");
  h.style.display = "none";
}

function hideitem() {
  let h = document.getElementById("showdata");
  h.style.display = "none";
  let p = document.getElementById("Hide");
  p.style.display = "none";
}
