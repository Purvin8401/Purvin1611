function form(event) {
  event.preventDefault();

  //first and last name
  var firstname = document.forminput.fname.value.trim();
  var lastname = document.forminput.lname.value.trim();
  let Gender = document.getElementById("gender").value;
  let bdate = document.forminput.birthday.value;
  let num = document.forminput.number.value.trim();
  let mail = document.forminput.email.value.trim();
  let pass = document.forminput.password.value;
  let repass = document.forminput.repassword.value;

  //firstname
  if (firstname == "" || firstname == null) {
    document.getElementById('fnameerror').textContent = "Input First Name";
    return false;
  } else if (!/^[A-Za-z]+$/.test(firstname)) {
    document.getElementById('fnameerror').textContent = "Fastname should only contain alphabates";
    return false;
  } else {
    document.getElementById('fnameerror').textContent = "";
  }

  //lastname
  if (lastname == "" || lastname == null) {
    document.getElementById('lnameerror').textContent = "Input First Name";
  } else if (!/^[A-Za-z]+$/.test(lastname)) {
    document.getElementById('lnameerror').textContent = "Lastname should only contain alphabates";
    return false;
  } else {
    document.getElementById('lnameerror').textContent = "";
  }

  //phone number
  if (num == null || num == "") {
    document.getElementById('numerror').textContent = "Please provide your Mobile Number";
    return false;
  } else if (/^\[0-9]{10}$/.test(num)) {
    document.getElementById('numerror').textContent = "Please  Enter a valid mobile number in 10 Digits";
    return false;
  } else {
    document.getElementById('numerror').textContent = "";
  }

  //email
  if (mail == "" || mail == null || !mail.includes('@')) {
    document.getElementById('emailerror').textContent = "please provide an email address";
    return false;
  } else {
    document.getElementById('emailerror').textContent = "";
  }

  // password
  if (pass == "" || pass == null) {
    document.getElementById('pwderror').textContent = "Please provide a password";
    return false;
  } else if (pass != repass) {
    document.getElementById('repwderror').textContent = "Passwords do not match.";
    return false;
  } else {
    document.getElementById('pwderror').textContent = "";
    document.getElementById('repwderror').textContent = "";
  }

  // local storage
  Gender.checked ? (gender = "Male") : (gender = "Female");

  // localStorage.setItem("Firstname", firstname);
  // localStorage.setItem("Lastname", lastname);
  // localStorage.setItem("Gender", Gender);
  // localStorage.setItem("Birthday", bdate);
  // localStorage.setItem("Phone_Number", num);
  // localStorage.setItem("Mail_Id", mail);
  // localStorage.setItem("Password", pass);

  var data = [{
    firstname: 'Purvin',
    lastname: 'Kachhiya',
    Gender: 'Male',
    bdate: '2001-04-08',
    num: "9876543210",
    mail: "Purvin@alians.com",
    pass: "789654213"
  }]
  
  localStorage.setItem("data",JSON.stringify(data));

  var retrivedData=JSON.parse(localStorage.getItem("data"));
  console.log(retrivedData);

}
// till date show
// function storedata() {
//   data.push(firstname);
//   data.push(lastname);
//   data.push(Gender);
//   data.push(bdate);
//   data.push(num);
//   data.push(mail);
//   data.push(pass);

// }
birthday.max = new Date().toISOString().split("T")[0];

// local storage to get item
/*function showitem() {
  let showitems = document.getElementById("showdata");
  showitems.style.display = "block";
  let hideitems = document.getElementById("Hide");
  hideitems.style.display = "block";

  document.getElementById("demo1").innerHTML = localStorage.getItem("");
  document.getElementById("demo2").innerHTML = localStorage.getItem("Firstname");
  document.getElementById("demo3").innerHTML = localStorage.getItem("Lastname");
  document.getElementById("demo4").innerHTML = localStorage.getItem("Gender");
  document.getElementById("demo5").innerHTML = localStorage.getItem("Birthday");
  document.getElementById("demo6").innerHTML = localStorage.getItem("Phone_Number");
  document.getElementById("demo7").innerHTML = localStorage.getItem("Mail_Id");
  document.getElementById("demo8").innerHTML = localStorage.getItem("Password");

}*/

/*function resetitem() {
  let show = document.getElementById("showdata");
  show.style.display = "none";
}*/

/*function hideitem() {
  let showitems = document.getElementById("showdata");
  showitems.style.display = "none";
  let hideitems = document.getElementById("Hide");
  hideitems.style.display = "none";
}*/

/*function cleardata() {
  localStorage.clear();
  alert('Data has been cleared');
}*/