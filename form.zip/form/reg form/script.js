function form() {
    const fName = document.forms.RegForm.firstname.value.trim();
    const lName = document.forms.RegForm.lastname.value.trim();
    const email = document.forms.RegForm.EMail.value.trim();
    const sub = document.forms.RegForm.Subject.value.trim();
    const password = document.forms.RegForm.Password.value.trim();
    const address = document.forms.RegForm.Address.value.trim();

    // document.getElementById("fn").innerHTML = fName;
    // document.getElementById("ln").innerHTML = lName;
    // document.getElementById("em").innerHTML = email;
    // document.getElementById("sb").innerHTML = sub;
    // document.getElementById("pass").innerHTML = password;
    // document.getElementById("add").innerHTML = address;


    // console.log(fName , lName , email , sub , password , address);

    //first name last name
    if (fName == "" || fName == null) {
        alert("Please enter your first name");
        return false;
    } else if (!/^[A-Za-z]+$/.test(fName)) {
        alert("First Name should only contain letters");
        return false;
    } else if (lName == "" || lName == null) {
        alert("Please enter your Last name");
        return false;
    } else if (!/^[A-Za-z]+$/.test(lName)) {
        alert("Last Name should only contain letters");
        return false;
    }

    if (address === "") {
        window.alert("Please enter your address.");
        address.focus();
        return false;
    }

    if (email === "" || !email.includes('@')) {
        window.alert
            ("Please enter a valid e-mail address.");
        email.focus();
        return false;
    }

    if (password === "") {
        alert("Please enter your password");
        password.focus();
        return false;
    }

    if (password.length < 6) {
        alert("Password should be atleast 6 character long");
        password.focus();
        return false;
    }

    if (sub.selectedIndex === -1) {
        alert("Please enter your course.");
        sub.focus();
        return false;
    }

    return true;
}

// Storing data in local storage

// function store() {
// localStorage.setItem("firstname", fName);
// localStorage.setItem("lastname", lName);

//     document.getElementById('result').innerHTML =
//      "Your First Name is: " + localStorage.getItem("firstname") + 
//      " and Your Last Name is:" + localStorage.getItem("lastname");
//     // You can also store objects by converting them to JSON strings
//     // const user = { name: 'Alice', age: 30 };
//     // localStorage.setItem('user', JSON.stringify(user));

//}