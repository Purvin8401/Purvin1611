function formsubmit(x) {
    x.preventDefault();
    var fName = document.forminput.firstname.value.trim();
    var lName = document.forminput.lastname.value.trim();

    // first name last name
    if (fName == "" || fName == null) {
        alert("Please enter your first name");
        return false;
    } else if (!/^[A-Za-z]+$/.test(fName)) {
        alert("First Name should only contain letters");
        return false;
    } else if (lName == "" || lName == null) {
        alert("Please enter your Last name");
        return false;
    } else if (!/^[A-Za-z]+$/.test(lName)) {
        alert("Last Name should only contain letters");
        return false;
    }

    //gender

    // birthdate Current
    const currentDate = new Date().toISOString().split("T")[0];
    document.getElementById('birthdate').setAttribute('max', currentDate);

    //mobile number
    var mobNo = document.forminput.contact.value.trim();

    if (mobNo == "" || mobNo == null) {
        alert("Please provide your Mobile Number");
        return false;
    } else if (!/^[0-9]{10}$/.test(mobNo)) {
        alert("Please  Enter a valid mobile number in 10 Digits")
        return false
    }

    //Email
    var Email = document.forminput.email.value.trim().toLowercase();

    if (Email == "" || Email == null || !email.includes('@')) {
        alert('please provide an email address');
        return false;
    }

    //password
    var pass = document.forminput.password.value;
    var repass = document.forminput.repassword.value;

    if (pass == "" || pass == null) {
        alert("Please provide a password");
        return false;
    } else if (pass.length > 5) {
        alert("Minimum 6 digits are required in the Password");
        return false;
    } else if (pass != repass) {
        alert("Passwords do not match.");
        return false;
    }

    localStorage.setItem("firstname", fName);
    localStorage.setItem("lastname", lName);
    document.getElementById('result').innerHTML =
        "Your First Name is: " + localStorage.getItem("firstname") +
        " and Your Last Name is:" + localStorage.getItem("lastname");
}

function getData() {
    var fn = localStorage.getItem('firstname');
    var ln = localStorage.getItem('lastname');
    document.getElementById('display').innerHTML = "Your First Name is: " + fn + " and Your Last Name is :" + ln;

}